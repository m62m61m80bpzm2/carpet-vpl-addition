package carpetvpladdition;

import carpet.CarpetExtension;
import carpet.CarpetServer;
import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1324;
import net.minecraft.class_3222;
import net.minecraft.class_5134;

public class CarpetVPLAdditionExtension implements CarpetExtension {
    private static final Gson GSON = new Gson();
    // 翻译缓存，避免每次请求都重新读资源流
    private final Map<String, Map<String, String>> translationCache = new ConcurrentHashMap<>();

    @Override
    public void onGameStarted() {
        try {
            CarpetServer.settingsManager.parseSettingsClass(CarpetVPLAdditionSettings.class);
            // 初始化所有字符串规则的数值缓存
            CarpetVPLAdditionSettings.syncNumericCaches();
        } catch (Exception e) {
            System.err.println("[carpet-vpl-addition] Failed to register settings: " + e.getMessage());
        }
    }

    @Override
    public void onPlayerLoggedIn(class_3222 player) {
        applyAttributes(player);
    }

    public static void applyAttributes(class_3222 player) {
        try {
            class_1324 healthAttr = player.method_5996(class_5134.field_23716);
            if (healthAttr != null) {
                healthAttr.method_6192(CarpetVPLAdditionSettings.maxPlayerHealthCached);
                player.method_6033(Math.min(player.method_6032(), (float) CarpetVPLAdditionSettings.maxPlayerHealthCached));
            }

            class_1324 damageAttr = player.method_5996(class_5134.field_23721);
            if (damageAttr != null) {
                damageAttr.method_6192(CarpetVPLAdditionSettings.playerAttackDamageCached);
            }

            class_1324 armorAttr = player.method_5996(class_5134.field_23724);
            if (armorAttr != null) {
                armorAttr.method_6192(CarpetVPLAdditionSettings.maxArmorCached);
            }
        } catch (Exception e) {
            System.err.println("[carpet-vpl-addition] Failed to apply attributes: " + e.getMessage());
        }
    }

    @Override
    public Map<String, String> canHasTranslations(String lang) {
        // 先从缓存取
        Map<String, String> cached = translationCache.get(lang);
        if (cached != null) return cached;

        // 未命中则加载资源流
        Map<String, String> result = loadTranslation(lang);
        translationCache.put(lang, result);
        return result;
    }

    private Map<String, String> loadTranslation(String lang) {
        InputStream langFile = null;
        try {
            langFile = CarpetVPLAdditionExtension.class.getResourceAsStream("/assets/carpet-vpl-addition/lang/" + lang + ".json");
            if (langFile == null) {
                langFile = CarpetVPLAdditionExtension.class.getResourceAsStream("/assets/carpet-vpl-addition/lang/" + lang.replace('-', '_') + ".json");
            }
            if (langFile == null) {
                return Collections.emptyMap();
            }
            String jsonData = new String(langFile.readAllBytes(), StandardCharsets.UTF_8);
            return GSON.fromJson(jsonData, new TypeToken<Map<String, String>>() {}.getType());
        } catch (Exception e) {
            System.err.println("[carpet-vpl-addition] Failed to load translations for " + lang + ": " + e.getMessage());
            return Collections.emptyMap();
        } finally {
            if (langFile != null) {
                try { langFile.close(); } catch (Exception ignored) {}
            }
        }
    }

    @Override
    public String version() {
        return "carpet-vpl-addition";
    }
}
