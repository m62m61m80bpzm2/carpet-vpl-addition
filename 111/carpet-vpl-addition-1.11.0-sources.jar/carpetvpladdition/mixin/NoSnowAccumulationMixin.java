package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_2338;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3218.class)
public class NoSnowAccumulationMixin {

    @Inject(method = "tickPrecipitation", at = @At("HEAD"), cancellable = true, require = 0)
    private void onTickPrecipitation(class_2338 pos, CallbackInfo ci) {
        if (CarpetVPLAdditionSettings.disableSnow) {
            ci.cancel();
        }
    }
}
