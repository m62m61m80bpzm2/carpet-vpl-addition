package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

/**
 * 修改最大饱食度。
 *
 * 性能修复：使用缓存的 maxSaturationCached，避免每次吃东西时 parseInt。
 */
@Mixin(class_1702.class)
public abstract class FoodDataMixin {
    @ModifyArg(
        method = "add",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/util/Mth;clamp(III)I"),
        index = 2
    )
    private int modifyFoodLevelCap(int original) {
        return CarpetVPLAdditionSettings.maxSaturationCached;
    }
}
