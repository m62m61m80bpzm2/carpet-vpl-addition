package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3218;
import net.minecraft.class_3852;
import net.minecraft.class_4140;
import net.minecraft.class_4142;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 村民吸引跟随。
 *
 * 性能修复：
 * 1. 从每 tick 降频到每 10 tick (0.5秒) 扫描一次玩家
 * 2. 只有当玩家移动距离 > 0.75 格才更新寻路目标，
 *    避免每 tick 设新 WalkTarget 导致大脑反复取消 + 重新寻路
 *    （大型村民交易所中，上百村民同时反复寻路 = MSPT 几十甚至上百）
 */
@Mixin(class_1646.class)
public abstract class VillagerAttractionMixin {
    @Unique
    private int scanCooldown = 0;

    @Unique
    private class_1657 lastTargetPlayer = null;

    @Unique
    private double lastTargetX, lastTargetZ;

    @Inject(method = "customServerAiStep", at = @At("TAIL"))
    private void onCustomServerAiStep(class_3218 level, CallbackInfo ci) {
        if (!CarpetVPLAdditionSettings.villagerAttraction) return;

        // 降频到每 10 tick 扫描一次
        if (--scanCooldown > 0) return;
        scanCooldown = 10;

        class_1646 self = (class_1646) (Object) this;
        class_1657 nearestPlayer = level.method_18460(self, 10.0);
        if (nearestPlayer == null || nearestPlayer.method_7325()) return;

        class_1799 mainHand = nearestPlayer.method_6047();
        class_1799 offHand = nearestPlayer.method_6079();
        if (isTempting(self, mainHand) || isTempting(self, offHand)) {
            if (self.method_5858(nearestPlayer) > 2.25) {
                // 仅在玩家移动超过 0.75 格时更新目标，避免反复触发寻路
                double dx = nearestPlayer.method_23317() - lastTargetX;
                double dz = nearestPlayer.method_23321() - lastTargetZ;
                if (lastTargetPlayer != nearestPlayer || (dx * dx + dz * dz) > 0.5625) {
                    self.method_18868().method_18878(class_4140.field_18445, new class_4142(nearestPlayer, 0.5F, 0));
                    lastTargetPlayer = nearestPlayer;
                    lastTargetX = nearestPlayer.method_23317();
                    lastTargetZ = nearestPlayer.method_23321();
                }
            }
        } else {
            lastTargetPlayer = null;
        }
    }

    private static boolean isTempting(class_1646 villager, class_1799 stack) {
        if (stack.method_31574(class_1802.field_8733)) return true;
        if (stack.method_31574(class_1802.field_8687) && villager.method_7231().comp_3521().method_40225(class_3852.field_17051)) return true;
        if (stack.method_31574(class_1802.field_8759) && !villager.method_7231().comp_3521().method_40225(class_3852.field_17051)) return true;
        if (stack.method_31574(class_1802.field_17534) && villager.method_6109()) return true;
        return false;
    }
}
