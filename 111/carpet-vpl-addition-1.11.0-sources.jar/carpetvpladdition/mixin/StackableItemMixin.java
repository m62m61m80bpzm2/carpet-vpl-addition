package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1812;
import net.minecraft.class_1822;
import net.minecraft.class_7707;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * 修改物品最大堆叠数。
 *
 * 性能优化（解决 MSPT 突然飙升的主因）：
 * 1. 如果所有堆叠规则都关闭，且漏斗矿车堆叠数为1，则直接返回，不侵入热路径
 * 2. hopperMinecartStackSize 使用缓存 int 值，避免运行时反复 Integer.parseInt
 */
@Mixin(class_1799.class)
public abstract class StackableItemMixin {
    @Inject(method = "getMaxStackSize", at = @At("HEAD"), cancellable = true)
    private void modifyMaxStackSize(CallbackInfoReturnable<Integer> cir) {
        // 快速跳过：没有任何堆叠规则开启时直接返回，不侵入最热路径
        if (!anyStackableEnabled() && CarpetVPLAdditionSettings.hopperMinecartStackSizeCached <= 1) {
            return;
        }

        class_1799 self = (class_1799) (Object) this;
        class_1792 item = self.method_7909();

        if (CarpetVPLAdditionSettings.stackableTotem && self.method_31574(class_1802.field_8288)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableLavaBucket && self.method_31574(class_1802.field_8187)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableBucket && self.method_31574(class_1802.field_8550)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableGlassBottle && self.method_31574(class_1802.field_8469)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableWaterBucket && self.method_31574(class_1802.field_8705)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableMilkBucket && self.method_31574(class_1802.field_8103)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackablePowderSnowBucket && self.method_31574(class_1802.field_27876)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableEnderPearl && self.method_31574(class_1802.field_8634)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableMusicDisc && self.method_57826(class_9334.field_52175)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableSign && (item instanceof class_1822 || item instanceof class_7707)) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackablePotion && item instanceof class_1812) {
            cir.setReturnValue(64);
            return;
        }

        if (CarpetVPLAdditionSettings.stackableStew) {
            class_1792 sItem = item;
            if (sItem == class_1802.field_8208 || sItem == class_1802.field_8766 ||
                sItem == class_1802.field_8308 || sItem == class_1802.field_8515) {
                cir.setReturnValue(64);
                return;
            }
        }

        if (CarpetVPLAdditionSettings.stackableCake && self.method_31574(class_1802.field_17534)) {
            cir.setReturnValue(64);
            return;
        }

        // 使用缓存的 int 值，避免 parseInt
        if (self.method_31574(class_1802.field_8836) && CarpetVPLAdditionSettings.hopperMinecartStackSizeCached > 1) {
            cir.setReturnValue(CarpetVPLAdditionSettings.hopperMinecartStackSizeCached);
        }
    }

    private static boolean anyStackableEnabled() {
        return CarpetVPLAdditionSettings.stackableTotem
            || CarpetVPLAdditionSettings.stackableLavaBucket
            || CarpetVPLAdditionSettings.stackableBucket
            || CarpetVPLAdditionSettings.stackableGlassBottle
            || CarpetVPLAdditionSettings.stackableWaterBucket
            || CarpetVPLAdditionSettings.stackableMilkBucket
            || CarpetVPLAdditionSettings.stackablePowderSnowBucket
            || CarpetVPLAdditionSettings.stackableEnderPearl
            || CarpetVPLAdditionSettings.stackableMusicDisc
            || CarpetVPLAdditionSettings.stackableSign
            || CarpetVPLAdditionSettings.stackablePotion
            || CarpetVPLAdditionSettings.stackableStew
            || CarpetVPLAdditionSettings.stackableCake;
    }
}
