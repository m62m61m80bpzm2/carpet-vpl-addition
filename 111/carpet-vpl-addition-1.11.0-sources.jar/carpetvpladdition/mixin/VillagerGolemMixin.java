package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1646;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2276;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2276.class)
public abstract class VillagerGolemMixin {
    @Inject(method = "trySpawnGolem", at = @At("TAIL"))
    private void onTrySpawnVillagerGolem(class_1937 level, class_2338 pos, CallbackInfo ci) {
        if (!CarpetVPLAdditionSettings.villagerGolem) return;

        class_2338 belowPos = pos.method_10074();
        class_2680 belowState = level.method_8320(belowPos);
        if (!belowState.method_27852(class_2246.field_10234)) return;

        level.method_8652(belowPos, class_2246.field_10124.method_9564(), 3);
        level.method_8652(pos, class_2246.field_10124.method_9564(), 3);

        class_1646 villager = class_1299.field_6077.method_5883(level, class_3730.field_16474);
        if (villager != null) {
            villager.method_5814(belowPos.method_10263() + 0.5, belowPos.method_10264() + 0.05, belowPos.method_10260() + 0.5);
            level.method_8649(villager);
            level.method_8396(null, belowPos, class_3417.field_19152, class_3419.field_15254, 1.0F, 1.0F);
        }
    }
}
