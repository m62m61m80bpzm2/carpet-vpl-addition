package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_2302;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_3225.class)
public class ImmatureCropProtectionMixin {

    @Shadow
    protected class_3222 player;

    @Inject(method = "destroyBlock", at = @At("HEAD"), cancellable = true)
    private void onDestroyBlock(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (!CarpetVPLAdditionSettings.protectImmatureCrops) return;
        class_2680 state = this.player.method_51469().method_8320(pos);
        if (state.method_26204() instanceof class_2302 crop && !crop.method_9825(state)) {
            cir.setReturnValue(false);
        }
    }
}
