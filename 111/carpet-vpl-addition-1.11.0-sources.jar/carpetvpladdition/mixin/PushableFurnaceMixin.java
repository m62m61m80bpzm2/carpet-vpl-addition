package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2363;
import net.minecraft.class_2665;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2665.class)
public abstract class PushableFurnaceMixin {
    @Inject(method = "isPushable", at = @At("HEAD"), cancellable = true)
    private static void allowFurnacePush(class_2680 state, class_1937 level, class_2338 pos, class_2350 direction, boolean allowDestroy, class_2350 pistonDirection, CallbackInfoReturnable<Boolean> cir) {
        if (CarpetVPLAdditionSettings.bedrockPushableFurnace && state.method_26204() instanceof class_2363) {
            cir.setReturnValue(true);
        }
    }
}
