package carpetvpladdition.mixin;

import net.minecraft.class_1863;
import net.minecraft.class_7225;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1863.class)
public interface RecipeManagerAccessor {
    @Accessor("registries")
    class_7225.class_7874 getRegistries();
}
