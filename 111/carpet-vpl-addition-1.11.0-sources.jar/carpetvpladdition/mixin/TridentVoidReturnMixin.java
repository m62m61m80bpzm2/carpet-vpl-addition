package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1685;
import net.minecraft.class_2940;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1685.class)
public abstract class TridentVoidReturnMixin {
    @Shadow
    private static class_2940<Byte> ID_LOYALTY;

    @Shadow
    protected abstract boolean isAcceptibleReturnOwner();

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTickTail(CallbackInfo ci) {
        if (!CarpetVPLAdditionSettings.tridentVoidReturn) return;

        class_1685 self = (class_1685) (Object) this;
        if (self.method_23318() >= self.method_37908().method_31607() - 10) return;

        int loyalty = self.method_5841().method_12789(ID_LOYALTY);
        if (loyalty <= 0) return;

        if (!isAcceptibleReturnOwner()) return;

        self.method_7433(true);
        self.method_18800(
            self.method_18798().field_1352,
            self.method_18798().field_1351 + 0.1,
            self.method_18798().field_1350
        );
    }
}
