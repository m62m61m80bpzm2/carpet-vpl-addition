package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Implements;
import org.spongepowered.asm.mixin.Interface;

@Mixin(class_2523.class)
@Implements(@Interface(iface = class_2256.class, prefix = "cane$"))
public abstract class SugarcaneBonemealMixin {

    public boolean cane$isValidBonemealTarget(class_4538 level, class_2338 pos, class_2680 state) {
        if (!CarpetVPLAdditionSettings.bedrockSugarcaneBonemeal) return false;
        if (!level.method_8320(pos.method_10084()).method_26215()) return false;
        int height = 1;
        class_2338 below = pos.method_10074();
        while (level.method_8320(below).method_27852(class_2246.field_10424) && height < 3) {
            height++;
            below = below.method_10074();
        }
        return height < 3;
    }

    public boolean cane$isBonemealSuccess(class_1937 level, class_5819 random, class_2338 pos, class_2680 state) {
        return CarpetVPLAdditionSettings.bedrockSugarcaneBonemeal;
    }

    public void cane$performBonemeal(class_3218 level, class_5819 random, class_2338 pos, class_2680 state) {
        if (!CarpetVPLAdditionSettings.bedrockSugarcaneBonemeal) return;
        if (!level.method_8320(pos.method_10084()).method_26215()) return;
        level.method_8501(pos.method_10084(), class_2246.field_10424.method_9564());
    }
}
