package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_2338;
import net.minecraft.class_2393;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2393.class)
public class NoKelpGrowthMixin {

    @Inject(method = "randomTick", at = @At("HEAD"), cancellable = true, require = 0)
    private void onRandomTick(class_2680 state, class_3218 level, class_2338 pos, class_5819 random, CallbackInfo ci) {
        if (CarpetVPLAdditionSettings.disableKelpGrowth) {
            ci.cancel();
        }
    }
}
