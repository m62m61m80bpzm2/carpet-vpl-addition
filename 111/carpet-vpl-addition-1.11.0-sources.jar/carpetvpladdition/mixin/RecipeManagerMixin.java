package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.mojang.serialization.JsonOps;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.Mixin;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10289;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8786;

@Mixin(value = class_1863.class, priority = 16888)
public abstract class RecipeManagerMixin {
    private static final Gson GSON = new Gson();
    private static final class_2960 TOTEM_ID = class_2960.method_60654("carpet-vpl-addition:totem_of_undying");

    private static final String TOTEM_RECIPE_JSON = """
        {
            "type": "minecraft:crafting_shaped",
            "category": "equipment",
            "pattern": ["ABA","CDC","DDD"],
            "key": {
                "A": "minecraft:golden_carrot",
                "B": "minecraft:enchanted_golden_apple",
                "C": "minecraft:emerald",
                "D": "minecraft:gold_block"
            },
            "result": {"id": "minecraft:totem_of_undying", "count": 1}
        }
        """;

    @ModifyReturnValue(
        method = "prepare(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)Lnet/minecraft/world/item/crafting/RecipeMap;",
        at = @At("RETURN")
    )
    private class_10289 addTotemRecipe(class_10289 original) {
        if (!CarpetVPLAdditionSettings.totemRecipe) return original;

        RecipeManagerAccessor accessor = (RecipeManagerAccessor) this;
        JsonObject json = GSON.fromJson(TOTEM_RECIPE_JSON, JsonObject.class);
        class_1860<?> recipe = class_1860.field_47319
            .parse(accessor.getRegistries().method_57093(JsonOps.INSTANCE), json)
            .getOrThrow();

        class_5321<class_1860<?>> recipeKey = class_5321.method_29179(class_7924.field_52178, TOTEM_ID);
        List<class_8786<?>> all = new ArrayList<>();
        original.method_64695().forEach(all::add);
        all.add(new class_8786<>(recipeKey, recipe));
        return class_10289.method_64700(all);
    }
}
