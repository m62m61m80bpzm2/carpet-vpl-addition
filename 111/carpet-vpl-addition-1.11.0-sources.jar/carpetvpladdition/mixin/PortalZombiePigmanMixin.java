package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import net.minecraft.class_1299;
import net.minecraft.class_1590;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2424;
import net.minecraft.class_3218;
import net.minecraft.class_3730;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 基岩版地狱门刷僵尸猪人。
 *
 * 修复：去掉 setPersistenceRequired()，避免实体不消失累积泄漏。
 * 僵尸猪人应像自然生成的怪物一样可以被正常清除。
 */
@Mixin(class_2424.class)
public abstract class PortalZombiePigmanMixin {
    @Shadow @Final private class_2350.class_2351 axis;
    @Shadow @Final private class_2338 bottomLeft;
    @Shadow @Final private int height;
    @Shadow @Final private int width;

    @Inject(method = "createPortalBlocks", at = @At("TAIL"))
    private void onCreatePortalBlocks(class_1936 level, CallbackInfo ci) {
        if (!CarpetVPLAdditionSettings.bedrockPortalZombiePigman) return;
        if (!(level instanceof class_3218 serverLevel)) return;

        if (serverLevel.field_9229.method_43057() >= 0.1f) return;

        int cx = bottomLeft.method_10263() + width / 2;
        int cy = bottomLeft.method_10264();
        int cz = bottomLeft.method_10260();
        int count = 1 + serverLevel.field_9229.method_43048(3);

        for (int i = 0; i < count; i++) {
            class_1590 pigman = class_1299.field_6050.method_5883(serverLevel, class_3730.field_16461);
            if (pigman != null) {
                double px = cx + serverLevel.field_9229.method_43058() * 4 - 2;
                double pz = cz + serverLevel.field_9229.method_43058() * 4 - 2;
                pigman.method_5814(px, cy + 1, pz);
                // 不设 setPersistenceRequired()，允许正常消失，避免实体泄漏
                serverLevel.method_8649(pigman);
            }
        }
    }
}
