package carpetvpladdition.mixin;

import carpetvpladdition.CarpetVPLAdditionExtension;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_3222.class)
public abstract class PlayerAttributeMixin {
    @Inject(method = "<init>*", at = @At("RETURN"))
    private void onInit(CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        CarpetVPLAdditionExtension.applyAttributes(self);
    }

    @Inject(method = "restoreFrom", at = @At("RETURN"))
    private void onRespawn(CallbackInfo ci) {
        class_3222 self = (class_3222) (Object) this;
        CarpetVPLAdditionExtension.applyAttributes(self);
    }
}
