package carpetvpladdition.mixin;

import carpetvpladdition.settings.CarpetVPLAdditionSettings;
import carpetvpladdition.util.CompoundTagValueOutput;
import carpetvpladdition.util.SpawnEggHelper;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_4140;
import net.minecraft.class_8942;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1646.class)
public abstract class VillagerReincarnationMixin {
    @Inject(method = "die", at = @At("HEAD"))
    private void onDie(class_1282 source, CallbackInfo ci) {
        if (!CarpetVPLAdditionSettings.villagerReincarnation) return;
        try {
            class_1646 self = (class_1646) (Object) this;
            class_1297 killer = source.method_5529();
            if (!(killer instanceof class_1309 livingKiller)) return;

            class_1799 weapon = livingKiller.method_6047();
            if (!weapon.method_31574(class_1802.field_8091)) return;
            if (!weapon.method_7942()) return;

            if (!(self.method_37908() instanceof class_3218 serverLevel)) return;

            self.method_18868().method_18875(class_4140.field_18439);
            self.method_18868().method_18875(class_4140.field_25160);

            self.method_18868().method_18875(class_4140.field_19386);

            CompoundTagValueOutput output = new CompoundTagValueOutput(
                class_8942.field_60348,
                serverLevel.method_30349().method_57093(class_2509.field_11560),
                new class_2487()
            );
            self.method_5647(output);
            class_2487 tag = output.buildResult();
            tag.method_10582("id", "minecraft:villager");

            tag.method_10551("Pos");
            tag.method_10551("Motion");
            tag.method_10551("Rotation");
            tag.method_10551("UUID");
            tag.method_10551("Health");
            tag.method_10551("Air");
            tag.method_10551("Fire");
            tag.method_10551("FallDistance");
            tag.method_10551("OnGround");
            tag.method_10551("DeathTime");
            tag.method_10551("HurtTime");
            tag.method_10551("HurtByTimestamp");
            tag.method_10551("PortalCooldown");
            tag.method_10551("FallFlying");
            tag.method_10551("AbsorptionAmount");
            tag.method_10551("Invulnerable");
            tag.method_10551("PersistenceRequired");
            tag.method_10551("CanPickUpLoot");
            tag.method_10551("LeftHanded");
            tag.method_10551("FoodLevel");
            tag.method_10551("ForcedAge");
            tag.method_10551("LastRestock");
            tag.method_10551("LastGossipDecay");
            tag.method_10551("RestocksToday");

            SpawnEggHelper.spawnVillagerEgg(self, serverLevel, tag);
        } catch (Throwable e) {
            System.err.println("[carpet-vpl-addition] VillagerReincarnation error: " + e.getMessage());
        }
    }
}
