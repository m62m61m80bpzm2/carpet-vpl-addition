package carpetvpladdition.settings;

import carpet.api.settings.CarpetRule;
import carpet.api.settings.Validator;
import net.minecraft.class_2168;

public class RecipeRuleObserver extends Validator<Boolean> {
    // 防重复执行标志
    private static boolean pendingReload = false;

    @Override
    public Boolean validate(class_2168 source, CarpetRule<Boolean> rule, Boolean newValue, String userInput) {
        Boolean oldValue = rule.value();
        if (oldValue != newValue) {
            onValueChange(source);
        }
        return newValue;
    }

    private void onValueChange(class_2168 source) {
        // 异步重载配方，避免在主线程同步执行完整 reloadResources
        if (source != null && source.method_9211() != null && !pendingReload) {
            pendingReload = true;
            source.method_9211().method_40000(() -> {
                try {
                    source.method_9211().method_29439(source.method_9211().method_3836().method_29210());
                } finally {
                    pendingReload = false;
                }
            });
        }
    }
}
