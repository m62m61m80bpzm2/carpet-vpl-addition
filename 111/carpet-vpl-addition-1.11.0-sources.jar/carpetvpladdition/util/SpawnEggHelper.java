package carpetvpladdition.util;

import net.minecraft.class_1542;
import net.minecraft.class_1646;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_9279;
import net.minecraft.class_9334;

public class SpawnEggHelper {
    public static void spawnVillagerEgg(class_1646 villager, class_3218 serverLevel, class_2487 tag) {
        class_1799 egg = new class_1799(class_1802.field_8086);
        egg.method_57379(class_9334.field_49609, class_9279.method_57456(tag));

        class_1542 itemEntity = new class_1542(
            serverLevel,
            villager.method_23317(), villager.method_23318(), villager.method_23321(),
            egg
        );
        serverLevel.method_8649(itemEntity);
    }
}
