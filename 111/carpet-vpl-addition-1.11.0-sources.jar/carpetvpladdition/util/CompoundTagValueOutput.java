package carpetvpladdition.util;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapCodec;
import net.minecraft.class_11372;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_8942;
import com.mojang.serialization.DataResult.Error;
import com.mojang.serialization.DataResult.Success;
import org.jetbrains.annotations.Nullable;

public class CompoundTagValueOutput implements class_11372 {
    private final class_8942 problemReporter;
    private final DynamicOps<class_2520> ops;
    private final class_2487 output;

    public CompoundTagValueOutput(class_8942 problemReporter, DynamicOps<class_2520> ops, class_2487 output) {
        this.problemReporter = problemReporter;
        this.ops = ops;
        this.output = output;
    }

    @Override
    public <T> void method_71468(String string, Codec<T> codec, T object) {
        switch (codec.encodeStart(this.ops, object)) {
            case Success<class_2520> success -> this.output.method_10566(string, success.value());
            case Error<class_2520> error -> {
                this.problemReporter.method_54947(new EncodeToFieldFailedProblem(string, object, error));
                error.partialValue().ifPresent(tag -> this.output.method_10566(string, tag));
            }
        }
    }

    @Override
    public <T> void method_71477(String string, Codec<T> codec, @Nullable T object) {
        if (object != null) {
            this.method_71468(string, codec, object);
        }
    }

    @Override
    public <T> void method_71460(MapCodec<T> mapCodec, T object) {
        switch (mapCodec.encoder().encodeStart(this.ops, object)) {
            case Success<class_2520> success -> this.output.method_10543((class_2487) success.value());
            case Error<class_2520> error -> {
                this.problemReporter.method_54947(new EncodeToMapFailedProblem(object, error));
                error.partialValue().ifPresent(tag -> this.output.method_10543((class_2487) tag));
            }
        }
    }

    @Override
    public void method_71472(String string, boolean bl) {
        this.output.method_10556(string, bl);
    }

    @Override
    public void method_71462(String string, byte b) {
        this.output.method_10567(string, b);
    }

    @Override
    public void method_71471(String string, short s) {
        this.output.method_10575(string, s);
    }

    @Override
    public void method_71465(String string, int i) {
        this.output.method_10569(string, i);
    }

    @Override
    public void method_71466(String string, long l) {
        this.output.method_10544(string, l);
    }

    @Override
    public void method_71464(String string, float f) {
        this.output.method_10548(string, f);
    }

    @Override
    public void method_71463(String string, double d) {
        this.output.method_10549(string, d);
    }

    @Override
    public void method_71469(String string, String string2) {
        this.output.method_10582(string, string2);
    }

    @Override
    public void method_71473(String string, int[] is) {
        this.output.method_10539(string, is);
    }

    @Override
    public class_11372 method_71461(String string) {
        class_2487 compoundTag = new class_2487();
        this.output.method_10566(string, compoundTag);
        return new CompoundTagValueOutput(
            this.problemReporter.method_54946(new class_8942.class_11333(string)),
            this.ops,
            compoundTag
        );
    }

    @Override
    public class_11372.class_11374 method_71476(String string) {
        class_2499 listTag = new class_2499();
        this.output.method_10566(string, listTag);
        return new ListWrapper(string, this.problemReporter, this.ops, listTag);
    }

    @Override
    public <T> class_11372.class_11373<T> method_71467(String string, Codec<T> codec) {
        class_2499 listTag = new class_2499();
        this.output.method_10566(string, listTag);
        return new TypedListWrapper<>(this.problemReporter, string, this.ops, codec, listTag);
    }

    @Override
    public void method_71478(String string) {
        this.output.method_10551(string);
    }

    @Override
    public boolean method_71457() {
        return this.output.method_33133();
    }

    public class_2487 buildResult() {
        return this.output;
    }

    public record EncodeToFieldFailedProblem(String name, Object value, Error<?> error) implements class_8942.class_11337 {
        @Override
        public String method_71358() {
            return "Failed to encode value '" + this.value + "' to field '" + this.name + "': " + this.error.message();
        }
    }

    public record EncodeToListFailedProblem(String name, Object value, Error<?> error) implements class_8942.class_11337 {
        @Override
        public String method_71358() {
            return "Failed to append value '" + this.value + "' to list '" + this.name + "': " + this.error.message();
        }
    }

    public record EncodeToMapFailedProblem(Object value, Error<?> error) implements class_8942.class_11337 {
        @Override
        public String method_71358() {
            return "Failed to merge value '" + this.value + "' to an object: " + this.error.message();
        }
    }

    static class ListWrapper implements class_11372.class_11374 {
        private final String fieldName;
        private final class_8942 problemReporter;
        private final DynamicOps<class_2520> ops;
        private final class_2499 output;

        ListWrapper(String string, class_8942 problemReporter, DynamicOps<class_2520> dynamicOps, class_2499 listTag) {
            this.fieldName = string;
            this.problemReporter = problemReporter;
            this.ops = dynamicOps;
            this.output = listTag;
        }

        @Override
        public class_11372 method_71480() {
            int i = this.output.size();
            class_2487 compoundTag = new class_2487();
            this.output.add(compoundTag);
            return new CompoundTagValueOutput(
                this.problemReporter.method_54946(new class_8942.class_11334(this.fieldName, i)),
                this.ops,
                compoundTag
            );
        }

        @Override
        public void method_71481() {
            this.output.removeLast();
        }

        @Override
        public boolean method_71482() {
            return this.output.isEmpty();
        }
    }

    static class TypedListWrapper<T> implements class_11372.class_11373<T> {
        private final class_8942 problemReporter;
        private final String name;
        private final DynamicOps<class_2520> ops;
        private final Codec<T> codec;
        private final class_2499 output;

        TypedListWrapper(class_8942 problemReporter, String string, DynamicOps<class_2520> dynamicOps, Codec<T> codec, class_2499 listTag) {
            this.problemReporter = problemReporter;
            this.name = string;
            this.ops = dynamicOps;
            this.codec = codec;
            this.output = listTag;
        }

        @Override
        public void method_71484(T object) {
            switch (this.codec.encodeStart(this.ops, object)) {
                case Success<class_2520> success -> this.output.add(success.value());
                case Error<class_2520> error -> {
                    this.problemReporter.method_54947(new CompoundTagValueOutput.EncodeToListFailedProblem(this.name, object, error));
                    error.partialValue().ifPresent(this.output::add);
                }
            }
        }

        @Override
        public boolean method_71483() {
            return this.output.isEmpty();
        }
    }
}
